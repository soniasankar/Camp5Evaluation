﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using StudentMangementSystem.Models;
using StudentManagementSystem.Repository; // Make sure this is included

namespace StudentManagementSystem.Service
{
    public class InvigilatorService : IInvigilatorService
    {
        private readonly IInvigilatorRepository _invigilatorRepository;

        public InvigilatorService(IInvigilatorRepository invigilatorRepository)
        {
            _invigilatorRepository = invigilatorRepository;
        }

        public async Task<Student> AddStudentAsync(Student student)
        {
            return await _invigilatorRepository.AddStudentAsync(student);
        }

        public async Task<bool> UpdateStudentAsync(Student student)
        {
            return await _invigilatorRepository.UpdateStudentAsync(student);
        }

        public async Task<bool> DeleteStudentAsync(int studentId)
        {
            return await _invigilatorRepository.DeleteStudentAsync(studentId);
        }

        public async Task<IEnumerable<Student>> GetAllStudentsAsync()
        {
            return await _invigilatorRepository.GetAllStudentsAsync();
        }

        public async Task<Student> GetStudentByRollNumberAsync(string rollNumber)
        {
            return await _invigilatorRepository.GetStudentByRollNumberAsync(rollNumber);
        }

        public async Task<Mark> AddMarkAsync(Mark mark)
        {
            return await _invigilatorRepository.AddMarkAsync(mark);
        }

        public async Task<bool> UpdateMarkAsync(Mark mark)
        {
            return await _invigilatorRepository.UpdateMarkAsync(mark);
        }
    }
}

