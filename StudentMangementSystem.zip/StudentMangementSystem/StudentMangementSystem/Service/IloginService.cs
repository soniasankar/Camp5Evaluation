﻿using StudentMangementSystem.Models;

namespace StudentMangementSystem.Service
{
    public interface IloginService
    {
        Task<Role> CheckUserCredentials(string username, string password);
    }
}
