﻿using StudentMangementSystem.Models;
using StudentMangementSystem.Repository.StudentManagementSystem.Repository;

namespace StudentMangementSystem.Service
{
   

        public class LoginServiceImp : IloginService
        {
            private readonly ILoginRepository _loginRepository;

            public LoginServiceImp(ILoginRepository loginRepository)
            {
                _loginRepository = loginRepository;
            }
            public async Task<Role> CheckUserCredentials(string username, string password)
            {
                var role = await _loginRepository.CheckUserCredentials(username, password);
                return role;
            }

        Task<Role> IloginService.CheckUserCredentials(string username, string password)
        {
            throw new NotImplementedException();
        }
    }
    }


