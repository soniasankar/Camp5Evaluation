﻿using System.Collections.Generic;
using System.Threading.Tasks;
using StudentMangementSystem.Models;

namespace StudentManagementSystem.Service
{
    public interface IInvigilatorService
    {
        Task<Student> AddStudentAsync(Student student);
        Task<bool> UpdateStudentAsync(Student student);
        Task<bool> DeleteStudentAsync(int studentId);
        Task<IEnumerable<Student>> GetAllStudentsAsync();
        Task<Student> GetStudentByRollNumberAsync(string rollNumber);
        Task<Mark> AddMarkAsync(Mark mark);
        Task<bool> UpdateMarkAsync(Mark mark);
    }
}
