﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentManagementSystem.Service;
using StudentMangementSystem.Models;
using StudentMangementSystem.Service;

namespace StudentManagementSystem.Controllers
{
    public class LoginController : Controller
    {
        private readonly IloginService _loginService;
        private readonly InvigilatorService _invigilatorService;

        public LoginController(IloginService loginService, IInvigilatorService invigilatorService)
        {
            _loginService = loginService;
            _invigilatorService = (InvigilatorService?)invigilatorService;
        }

        // GET: Login/Index
        public IActionResult Index()
        {
            return View(new User());
        }

        // POST: Login/Index
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(User user)
        {
            try
            {
                // Call the service to check user credentials
                var role = await _loginService.CheckUserCredentials(user.Username, user.Password);

                if (role != null && role.RoleName == "Invigilator") // Check if the user is an invigilator
                {
                    // Get the invigilator ID
                    //  var invigilatorId = await _invigilatorService.(role.RoleName, user.Username);
                    //  if (invigilatorId.HasValue)
                    // {
                    // Store the InvigilatorId in session
                    //HttpContext.Session.SetInt32("InvigilatorId", invigilatorId.Value);
                    // Redirect to the Invigilator Dashboard
                    return RedirectToAction("Index", "InvigilatorDashboard");
                    //  }
                    // else
                    // {
                    //  ViewData["ErrorMessage"] = "Invigilator ID not found.";
                    // }
                }
                else
                {
                    // Role is null or not Invigilator, set error message
                    ViewData["ErrorMessage"] = "Invalid username or password.";
                }
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                ViewData["ErrorMessage"] = "An unexpected error occurred. Please try again later.";
                // Log the exception details
                Console.WriteLine($"Exception: {ex.Message}");
            }

            // Return the view with the current model and any error messages
            return View(user);
        }
    }
}
