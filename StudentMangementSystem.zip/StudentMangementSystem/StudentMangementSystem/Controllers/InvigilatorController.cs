﻿using Microsoft.AspNetCore.Mvc;

using StudentManagementSystem.Service;
using StudentMangementSystem.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StudentManagementSystem.Controllers
{
    public class InvigilatorController : Controller
    {
        private readonly IInvigilatorService _invigilatorService;

        public InvigilatorController(IInvigilatorService invigilatorService)
        {
            _invigilatorService = invigilatorService;
        }

        // GET: Invigilator
        public async Task<IActionResult> Index()
        {
            var students = await _invigilatorService.GetAllStudentsAsync();
            return View(students);
        }

        // GET: Invigilator/Add
        public IActionResult Add()
        {
            return View();
        }

        // POST: Invigilator/Add
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Student student)
        {
            if (ModelState.IsValid)
            {
                await _invigilatorService.AddStudentAsync(student);
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        // GET: Invigilator/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var student = await _invigilatorService.GetStudentByRollNumberAsync(id.ToString());
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // POST: Invigilator/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Student student)
        {
            if (id != student.StudentId)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _invigilatorService.UpdateStudentAsync(student);
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        // GET: Invigilator/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var student = await _invigilatorService.GetStudentByRollNumberAsync(id.ToString());
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // POST: Invigilator/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _invigilatorService.DeleteStudentAsync(id);
            return RedirectToAction(nameof(Index));
        }

        // GET: Invigilator/AddMark
        public IActionResult AddMark()
        {
            return View();
        }

        // POST: Invigilator/AddMark
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddMark(Mark mark)
        {
            if (ModelState.IsValid)
            {
                await _invigilatorService.AddMarkAsync(mark);
                return RedirectToAction(nameof(Index));
            }
            return View(mark);
        }

        // GET: Invigilator/UpdateMark/{id}
        public async Task<IActionResult> UpdateMark(int id)
        {
            // Implementation for retrieving mark by id
            // You may need to create a method in your service to get marks by student or ID
            return View(); // Replace with your actual logic
        }

        // POST: Invigilator/UpdateMark/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateMark(int id, Mark mark)
        {
            if (id != mark.MarksId)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _invigilatorService.UpdateMarkAsync(mark);
                return RedirectToAction(nameof(Index));
            }
            return View(mark);
        }
    }
}
