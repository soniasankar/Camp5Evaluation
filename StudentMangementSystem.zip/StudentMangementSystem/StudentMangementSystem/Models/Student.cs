﻿namespace StudentMangementSystem.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public int UserId { get; set; }
        public string RollNumber { get; set; } // 5-digit roll number
        public string Name { get; set; } // Max 30 characters

        public User User { get; set; } // Navigation property
    }

}
