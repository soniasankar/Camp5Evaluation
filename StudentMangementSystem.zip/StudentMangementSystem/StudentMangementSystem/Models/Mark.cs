﻿namespace StudentMangementSystem.Models
{
    public class Mark
    {
        public int MarksId { get; set; }
        public int StudentId { get; set; }
        public int SubjectId { get; set; }
        public int Marks { get; set; } // Between 1 and 100

        public Student Student { get; set; } // Navigation property
        public Subject Subject { get; set; } // Navigation property
    }

}
