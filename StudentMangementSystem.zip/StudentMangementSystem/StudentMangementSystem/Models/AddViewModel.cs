﻿namespace StudentMangementSystem.Models
{
    public class AddViewModel
    {
    }
}
