﻿
using System.Data;
 // Updated namespace
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using StudentMangementSystem.Models;
using StudentMangementSystem.Repository.StudentManagementSystem.Repository;
using System.Data.SqlClient;

namespace StudentManagementSystem.Repository // Updated namespace
{
    public class LoginRepositoryImp : ILoginRepository
    {
        private readonly string connectionString;

        public LoginRepositoryImp(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public async Task<Role> CheckUserCredentials(string username, string password)
        {
            const string storedProcedure = "Sp_CheckUserCredentials";
            Role role = null;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                using (var command = new SqlCommand(storedProcedure, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Add parameters for the stored procedure
                    command.Parameters.Add(new SqlParameter("@Username", SqlDbType.NVarChar, 255)).Value = username;
                    command.Parameters.Add(new SqlParameter("@Password", SqlDbType.NVarChar, 255)).Value = (password); // Ensure this method hashes the password

                    await connection.OpenAsync();

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            role = new Role
                            {
                                RoleId = reader.GetInt32(reader.GetOrdinal("RoleId")),
                                RoleName = reader.GetString(reader.GetOrdinal("RoleName")),
                                IsActive = reader.GetBoolean(reader.GetOrdinal("IsActive"))
                            };
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Log SQL exception details
                throw new Exception("An error occurred while retrieving role details from the database.", ex);
            }
            catch (Exception ex)
            {
                // Log general exceptions
                throw new Exception("An unexpected error occurred while processing your request.", ex);
            }

            return role;
        }

        
    }
}
