﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using StudentMangementSystem.Models;

namespace StudentManagementSystem.Repository
{
    public class InvigilatorRepositoryImp : IInvigilatorRepository
    {
        private readonly string connectionString;

        public InvigilatorRepositoryImp(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }

        public async Task<Student> AddStudentAsync(Student student)
        {
            const string storedProcedure = "sp_AddStudent"; // Adjust the stored procedure name accordingly

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int)).Value = student.UserId;
                command.Parameters.Add(new SqlParameter("@RollNumber", SqlDbType.Char, 5)).Value = student.RollNumber;
                command.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar, 30)).Value = student.Name;

                await connection.OpenAsync();
                await command.ExecuteNonQueryAsync();

                return student; // You can return the created student or its ID as needed
            }
        }

        public async Task<bool> UpdateStudentAsync(Student student)
        {
            const string storedProcedure = "sp_UpdateStudent"; // Adjust the stored procedure name accordingly

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@StudentId", SqlDbType.Int)).Value = student.StudentId;
                command.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int)).Value = student.UserId;
                command.Parameters.Add(new SqlParameter("@RollNumber", SqlDbType.Char, 5)).Value = student.RollNumber;
                command.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar, 30)).Value = student.Name;

                await connection.OpenAsync();
                int rowsAffected = await command.ExecuteNonQueryAsync();
                return rowsAffected > 0;
            }
        }

        public async Task<bool> DeleteStudentAsync(int studentId)
        {
            const string storedProcedure = "sp_DeleteStudent"; // Adjust the stored procedure name accordingly

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@StudentId", SqlDbType.Int)).Value = studentId;

                await connection.OpenAsync();
                int rowsAffected = await command.ExecuteNonQueryAsync();
                return rowsAffected > 0;
            }
        }

        public async Task<IEnumerable<Student>> GetAllStudentsAsync()
        {
            const string storedProcedure = "sp_GetAllStudents"; // Adjust the stored procedure name accordingly
            var students = new List<Student>();

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                await connection.OpenAsync();

                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        students.Add(new Student
                        {
                            StudentId = reader.GetInt32(reader.GetOrdinal("StudentId")),
                            UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                            RollNumber = reader.GetString(reader.GetOrdinal("RollNumber")),
                            Name = reader.GetString(reader.GetOrdinal("Name"))
                        });
                    }
                }
            }
            return students;
        }
        public async Task<Mark> AddMarkAsync(Mark mark)
        {
            const string storedProcedure = "sp_AddMark"; // Adjust the stored procedure name accordingly

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@StudentId", SqlDbType.Int)).Value = mark.StudentId;
                command.Parameters.Add(new SqlParameter("@SubjectId", SqlDbType.Int)).Value = mark.SubjectId;
                command.Parameters.Add(new SqlParameter("@Marks", SqlDbType.Int)).Value = mark.Marks;

                await connection.OpenAsync();
                await command.ExecuteNonQueryAsync();

                return mark; // You can return the created mark or its ID as needed
            }
        }

        // New method to update marks
        public async Task<bool> UpdateMarkAsync(Mark mark)
        {
            const string storedProcedure = "sp_UpdateMark"; // Adjust the stored procedure name accordingly

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@MarksId", SqlDbType.Int)).Value = mark.MarksId;
                command.Parameters.Add(new SqlParameter("@StudentId", SqlDbType.Int)).Value = mark.StudentId;
                command.Parameters.Add(new SqlParameter("@SubjectId", SqlDbType.Int)).Value = mark.SubjectId;
                command.Parameters.Add(new SqlParameter("@Marks", SqlDbType.Int)).Value = mark.Marks;

                await connection.OpenAsync();
                int rowsAffected = await command.ExecuteNonQueryAsync();
                return rowsAffected > 0;
            }
        }
        public async Task<Student> GetStudentByRollNumberAsync(string rollNumber)
        {
            const string storedProcedure = "sp_GetStudentByRollNumber"; // Adjust the stored procedure name accordingly
            Student student = null;

            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(storedProcedure, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@RollNumber", SqlDbType.Char, 5)).Value = rollNumber;

                await connection.OpenAsync();
                using (var reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        student = new Student
                        {
                            StudentId = reader.GetInt32(reader.GetOrdinal("StudentId")),
                            UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                            RollNumber = reader.GetString(reader.GetOrdinal("RollNumber")),
                            Name = reader.GetString(reader.GetOrdinal("Name"))
                        };
                    }
                }
            }
            return student;
        }
    }
}
