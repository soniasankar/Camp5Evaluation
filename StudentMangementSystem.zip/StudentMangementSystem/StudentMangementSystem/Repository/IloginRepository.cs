﻿namespace StudentMangementSystem.Repository
{
   
        using System.Threading.Tasks;

    using StudentMangementSystem.Models;

    namespace StudentManagementSystem.Repository
{
    public interface ILoginRepository
    {
        Task<Role> CheckUserCredentials(string username, string password);
    }
}

    }
